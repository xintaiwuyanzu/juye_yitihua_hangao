const onload = {
  loadImg(canvas) {
    return new Prom
  }
}
export default onload