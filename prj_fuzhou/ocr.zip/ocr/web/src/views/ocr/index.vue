<template>
  <table-index :delete="false" :edit="false" :fields="fields" :insert="false" path="ocr" ref="table">
    <template v-slot:search-$btns="scope">
      <el-button type="primary" @click="visible=true">上传图片</el-button>
    </template>
    <template v-slot:table-$btns="scope">
      <el-button @click="viewImg(scope.row)" size="mini" type="primary" width="100">查看</el-button>
    </template>
    <el-dialog title="ocr图片识别" :visible.sync="visible">
      <div style="text-align: center">
        <el-upload
            class="upload-demo"
            drag
            :file-list="fileList"
            :auto-upload="false"
            :on-success="onSuccess"
            ref="upload"
            action="/api/ocr/upload"
            multiple>
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip" slot="tip">
            不超过10M，支持jpeg、jpg、png、pdf、bmp、tiff格式
          </div>
        </el-upload>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="visible = false,loading=false">取 消</el-button>
        <el-button :loading="loading" @click="sure" type="primary">保存</el-button>
      </span>
    </el-dialog>
  </table-index>
</template>

<script>
  export default {
    name: "index",
    data() {
      return {
        visible: false,
        fileList: [],
        loading: false,
        fields: [
          {prop: 'fileName', label: '图片名称'},
          {prop: 'createPerson', label: '创建人'},
          {prop: 'updateDate', label: '识别时间', dateFormat: 'YYYY-MM-DD HH:mm:ss', sortable: true}
        ]
      }
    },
    methods: {
      onSuccess(response) {
        this.$message({
          message: response.message,
          type: response.success ? 'success' : 'error'
        });
        this.visible = false;
        this.fileList = [];
        this.$refs.table.loadData();
        this.loading = false
      },
      sure() {
        this.loading = true;
        this.$refs.upload.submit()
      },
      viewImg(record) {
        this.$router.push({
          path: '/ocr/viewResult',
          query: {
            id: record.id
          }
        })
      }
    }
  }
</script>

<style scoped>

</style>