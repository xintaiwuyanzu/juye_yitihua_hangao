<template>
  <section>
    <nac-info back/>
    <div class="box">
      <el-card class="card">
        <h3>识别结果</h3><br>
        <div class="page">
          <span style="margin-right: 10px">{{index+1}}/{{length-1}}</span>
          <el-button :disabled="index===0" @click="index--" size="mini"><i class="el-icon-back">上一页</i></el-button>
          <el-button :disabled="index+1===length-1" @click="index++" size="mini"><i class="el-icon-right">下一页</i>
          </el-button>
        </div>
        <img :src="'/api/ocr/download?id='+$route.query.id+'&index='+this.index" ref="image" v-show="false"/>
        <canvas height="1000" id="canvas" ref="canvas" width="800"></canvas>
      </el-card>
      <el-divider direction="vertical"/>
      <el-card class="card">
        <h3>识别内容</h3><br>
        <svg height="1000" v-loading="loading" version="1.2" width="100%" xmlns="http://www.w3.org/2000/svg">
          <text :stroke="(contents[index]&&row_id===contents[index].row_id)?'red':''" :x="i.positions[0].x"
                :y="i.positions[0].y"
                font-size="0.9em" v-for="(i,index) in items">
            {{contents[index]!==undefined?i.content:''}}
          </text>
        </svg>
      </el-card>
    </div>
  </section>
</template>
<script>
  import {fabric} from "fabric";

  export default {
    name: "index",
    data() {
      return {
        canvas: null,
        id: '',
        row_id: '',
        items: [],
        loading: true,
        contents: [],
        length: 1,
        index: 0
      }
    },
    methods: {
      $init() {
        //使用canvas图片文字提取
        this.canvas = new fabric.Canvas("canvas");
        this.setBackgroundImage()
      },
      byFabricJs() {
        this.items.forEach((i, index) => {
          const p = i.positions[0];
          const p1 = i.positions[1];
          const p2 = i.positions[2];
          if (this.contents[index] !== undefined) {
            const option = {
              left: p.x,
              top: p.y,
              width: p1.x - p.x,
              height: p2.y - p.y,
              fill: 'rgba(183, 207, 251,0.4)',
              hoverCursor: 'pointer',
              lockMovementX: true,
              lockMovementY: true
            };
            let rect = new fabric.Rect(option);
            let that = this
            rect.on('selected', function () {
              that.row_id = that.contents[index].row_id;
            });
            this.canvas.add(rect)
          }
        })
        this.loading = false
        this.$message({
          type: 'success',
          message: '识别成功！'
        })
      },
      loadData() {
        const id = this.$route.query.id;
        this.$post('ocr/getTextMessage', {id, index: this.index}).then(({data}) => {
          if (data && data.success) {
            let result = data.data
            if (typeof data.data === 'string') {
              result = JSON.parse(data.data)
            }
            this.contents = result.struct_content.row
            this.items = result.items
            this.byFabricJs()
          } else {
            throw new Error(data.message)
          }
        }).catch(err => {
          this.$message({
            type: 'error',
            message: err.message + ', 识别失败!'
          })
        });
      },
      setBackgroundImage() {
        let img = this.$refs.image
        img.onload = () => {
          this.canvas.setBackgroundImage('/api/ocr/download?id=' + this.$route.query.id + '&index=' + this.index, this.canvas.renderAll.bind(this.canvas), {
            scaleX: img.width > this.canvas.width ? (this.canvas.width / img.width) : 1,
            scaleY: img.height > this.canvas.height ? (this.canvas.height / img.height) : 1
          });
        }
      }
    },
    watch: {
      index() {
        this.loading = true
        this.canvas.clear()
        this.setBackgroundImage()
        this.loadData()
      }
    },
    mounted() {
      //获取识别后的文字信息
      this.loadData()
      const id = this.$route.query.id;
      this.$post('ocr/detail', {id}).then(({data}) => {
        this.length = data.data.toFiles.split(',').length
      });
    }
  }
</script>

<style scoped>
  .box {
    display: flex;
    flex-direction: row;
    justify-content: center;
  }

  .card {
    padding: 10px;
    flex: 1;
    height: 700px;
    overflow: scroll;
  }

  .page {
    display: flex;
    justify-content: right;
    line-height: 40px;
  }
</style>