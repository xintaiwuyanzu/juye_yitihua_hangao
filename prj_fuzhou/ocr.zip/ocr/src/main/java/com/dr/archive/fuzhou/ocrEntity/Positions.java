package com.dr.archive.fuzhou.ocrEntity;


/**
 * @author: yang
 * @create: 2022-05-20 09:17
 **/
public class Positions {
    private int x;
    private int y;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
