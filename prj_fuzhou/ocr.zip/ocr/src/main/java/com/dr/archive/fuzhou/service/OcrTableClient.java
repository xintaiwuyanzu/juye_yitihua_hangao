package com.dr.archive.fuzhou.service;

import com.dr.archive.fuzhou.ocrEntity.TableBo;
import com.dr.archive.fuzhou.ocrEntity.TableResult;
import com.dr.archive.fuzhou.service.impl.FeignClientTableConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * ofd接口客户端
 *
 * @author yang
 * @date 2022-05-19 10:38
 */
@FeignClient(name = "ocr-table-client", url = "${ocr.base-url}", configuration = FeignClientTableConfig.class)
public interface OcrTableClient {

    /**
     * 通用表格识别
     *
     * @param tableBo
     * @return
     */
    @PostMapping(value = "v1/mage/ocr/table")
    TableResult table(@RequestBody TableBo tableBo);
}
