package com.dr.archive.fuzhou.util;

import com.dr.framework.common.file.autoconfig.CommonFileConfig;
import com.github.jaiimageio.impl.plugins.tiff.TIFFImageReaderSpi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.spi.IIORegistry;
import javax.imageio.spi.ImageReaderSpi;
import javax.imageio.stream.FileImageInputStream;
import javax.imageio.stream.ImageInputStream;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Date;

/**
 * @author: yang
 * @create: 2022-05-24 11:10
 **/
@Component
public class TifToImg {

    @Autowired
    CommonFileConfig fileConfig;

    public String tiffToJpg(String fromPath, String uid) {
        int pages = 0;
        StringBuilder buffer = new StringBuilder();
        BufferedImage[] bi;
        File tiffFile = new File(fromPath);
        ImageReader tiffReader = null;
        ImageInputStream input;
        try {
            input = new FileImageInputStream(tiffFile);
            IIORegistry registry = IIORegistry.getDefaultInstance();
            registry.registerApplicationClasspathSpis();
            ImageReaderSpi irs = new TIFFImageReaderSpi();
            tiffReader = irs.createReaderInstance();
            tiffReader.setInput(input);
            pages = tiffReader.getNumImages(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String path = fileConfig.getFullDirPath("OCR", "from", new Date());
        if (pages > 0) {
            bi = new BufferedImage[pages];
            for (int i = 0; i < pages; i++) {

                try {
                    bi[i] = tiffReader.read(i);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Image image = bi[i].getScaledInstance(800, 1000, Image.SCALE_DEFAULT);
                BufferedImage tag = new BufferedImage(800, 1000, BufferedImage.TYPE_INT_BGR);
                Graphics g = tag.getGraphics();
                g.drawImage(image, 0, 0, null);
                g.dispose();
                try {
                    File file = new File(path + "\\" + uid + "_" + i + ".jpg");
                    buffer.append(file.getName()).append(",");
                    ImageIO.write(tag, "jpg", file);
                    System.out.println("转换成功！");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return buffer.toString();
    }

}

