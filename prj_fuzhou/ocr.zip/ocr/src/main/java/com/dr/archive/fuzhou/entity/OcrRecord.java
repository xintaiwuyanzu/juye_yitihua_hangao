package com.dr.archive.fuzhou.entity;

import com.dr.archive.util.Constants;
import com.dr.framework.common.entity.BaseStatusEntity;
import com.dr.framework.core.orm.annotations.Column;
import com.dr.framework.core.orm.annotations.Table;

/**
 * @author: yang
 * @create: 2022-05-19 11:50
 **/
@Table(name = Constants.TABLE_PREFIX + "Ocr_Record", module = Constants.MODULE_NAME, comment = "OCR图像识别记录")
public class OcrRecord extends BaseStatusEntity<String> {
    @Column(comment = "图片fileUid")
    private String fileUid;
    @Column(comment = "图片名字")
    private String fileName;
    @Column(comment = "图片类型")
    private String fileType;
    @Column(comment = "图片大小")
    private long fileSize;
    @Column(comment = "转换后文件")
    private String toFiles;

    public OcrRecord() {
    }

    public OcrRecord(String fileUid, String fileName, String fileType, long fileSize, String toFiles) {
        this.fileUid = fileUid;
        this.fileName = fileName;
        this.fileType = fileType;
        this.fileSize = fileSize;
        this.toFiles = toFiles;
    }

    public String getFileUid() {
        return fileUid;
    }

    public void setFileUid(String fileUid) {
        this.fileUid = fileUid;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public String getToFiles() {
        return toFiles;
    }

    public void setToFiles(String toFiles) {
        this.toFiles = toFiles;
    }
}
