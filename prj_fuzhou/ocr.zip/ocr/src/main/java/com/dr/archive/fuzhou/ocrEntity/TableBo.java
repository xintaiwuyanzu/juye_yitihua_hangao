package com.dr.archive.fuzhou.ocrEntity;

import java.util.List;

/**
 * 通用表格的
 *
 * @author yang
 * @date 2022-05-19 10:38
 */
public class TableBo {
    List<String> img_base64;

    public TableBo() {
    }

    public TableBo(List<String> img_base64) {
        this.img_base64 = img_base64;
    }

    public List<String> getImg_base64() {
        return img_base64;
    }

    public void setImg_base64(List<String> img_base64) {
        this.img_base64 = img_base64;
    }
}
