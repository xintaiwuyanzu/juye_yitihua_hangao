package com.dr.archive.fuzhou.ocrEntity;


/**
 * @author: yang
 * @create: 2022-05-20 09:18
 **/
public class Row {
    private String content;
    private String row_id;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getRow_id() {
        return row_id;
    }

    public void setRow_id(String row_id) {
        this.row_id = row_id;
    }
}
