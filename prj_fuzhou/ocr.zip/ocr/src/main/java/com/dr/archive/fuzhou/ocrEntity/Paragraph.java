package com.dr.archive.fuzhou.ocrEntity;

/**
 * @author: yang
 * @create: 2022-05-20 09:18
 **/
public class Paragraph {
    private String content;
    private String paragraph_id;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getParagraph_id() {
        return paragraph_id;
    }

    public void setParagraph_id(String paragraph_id) {
        this.paragraph_id = paragraph_id;
    }
}
