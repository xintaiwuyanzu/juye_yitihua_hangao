package com.dr.archive.fuzhou.ocrEntity;

import java.util.List;

/**
 * @author: yang
 * @create: 2022-05-20 09:18
 **/
public class StructContent {
    private List<Page> page;
    private List<Paragraph> paragraph;
    private List<Row> row;

    public List<Page> getPage() {
        return page;
    }

    public void setPage(List<Page> page) {
        this.page = page;
    }

    public List<Paragraph> getParagraph() {
        return paragraph;
    }

    public void setParagraph(List<Paragraph> paragraph) {
        this.paragraph = paragraph;
    }

    public List<Row> getRow() {
        return row;
    }

    public void setRow(List<Row> row) {
        this.row = row;
    }
}
