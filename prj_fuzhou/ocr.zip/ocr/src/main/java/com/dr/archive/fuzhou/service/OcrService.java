package com.dr.archive.fuzhou.service;

import com.dr.archive.fuzhou.entity.OcrRecord;
import com.dr.framework.common.entity.ResultEntity;
import com.dr.framework.common.service.BaseService;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 * @author yang
 * @date 2022-05-19 10:38
 */
public interface OcrService extends BaseService<OcrRecord> {
    /**
     * 在线图片转换成base64字符串
     */
    String imageToBase64(OcrRecord ocrRecord);

    void upload(MultipartFile file);

    void download(String id, int index, HttpServletResponse response);

    ResultEntity getTextMessage(String id, int index);
}