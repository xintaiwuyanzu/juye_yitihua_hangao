package com.dr.archive.fuzhou.ocrEntity;


/**
 * @author: yang
 * @create: 2022-05-20 09:18
 **/
public class Page {
    private String content;
    private String page_id;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPage_id() {
        return page_id;
    }

    public void setPage_id(String page_id) {
        this.page_id = page_id;
    }
}
