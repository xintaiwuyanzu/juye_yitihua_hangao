package com.dr.archive.fuzhou.autoConfig;

import com.dr.archive.fuzhou.OcrConfig;
import com.dr.archive.fuzhou.service.OcrGeneralClient;
import com.dr.archive.fuzhou.service.OcrTableClient;
import com.dr.archive.fuzhou.service.OcrTemplateClient;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

/**
 * @author: yang
 * @create: 2022-05-19 15:38
 **/
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(OcrConfig.class)
@EnableFeignClients(clients = {OcrGeneralClient.class, OcrTableClient.class, OcrTemplateClient.class})
public class OcrAutoConfig {
}
