package com.dr.archive.fuzhou.controller;

import com.dr.archive.fuzhou.entity.OcrRecord;
import com.dr.archive.fuzhou.entity.OcrRecordInfo;
import com.dr.archive.fuzhou.ocrEntity.*;
import com.dr.archive.fuzhou.service.OcrGeneralClient;
import com.dr.archive.fuzhou.service.OcrService;
import com.dr.archive.fuzhou.service.OcrTableClient;
import com.dr.archive.fuzhou.service.OcrTemplateClient;
import com.dr.framework.common.controller.BaseServiceController;
import com.dr.framework.common.entity.ResultEntity;
import com.dr.framework.core.orm.sql.support.SqlQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ocr")
public class OcrController extends BaseServiceController<OcrService, OcrRecord> {
    Logger logger = LoggerFactory.getLogger(OcrController.class);
    @Autowired
    OcrGeneralClient ocrGeneralClient;
    @Autowired
    OcrTemplateClient ocrTemplateClient;
    @Autowired
    OcrTableClient ocrTableClient;

    /**
     * 通用文字识别
     */
    @RequestMapping("/imageToBase64")
    public ResultEntity imageToBase64(OcrRecord ocrRecord) {
        String img = service.imageToBase64(ocrRecord);
        List<String> img_base64List = new ArrayList<>();
        img_base64List.add(img);
        GeneralBo generalBo = new GeneralBo(true, true, img_base64List);
        GeneralResult generalResult = ocrGeneralClient.general(generalBo);
        logger.info("通用文字识别成功:{}", generalResult);
        return ResultEntity.success((generalResult.getData()));
    }

    /**
     * 模板识别
     */
    @RequestMapping("/template")
    public ResultEntity template(OcrRecord ocrRecord) {
        Map<String, String> result = new HashMap<>();
        String img = service.imageToBase64(ocrRecord);
        TemplateBo templateBo = new TemplateBo(img, true, true);
        TemplateResult templateResultEntity = ocrTemplateClient.template(templateBo);
        logger.info("自定义模板识别成功:{}", templateResultEntity.getData());
        return ResultEntity.success(result);
    }

    /**
     * 获取table
     */
    @RequestMapping("/table")
    public ResultEntity table(@RequestParam MultipartFile file) throws IOException {
        String img = Base64Utils.encodeToString(file.getBytes());
        List<String> img_base64List = new ArrayList<>();
        img_base64List.add(img);
        TableBo tableBo = new TableBo(img_base64List);
        TableResult tableResultEntity = ocrTableClient.table(tableBo);
        logger.info("通用表格识别成功:{}", tableResultEntity);
        return ResultEntity.success((tableResultEntity.getData()));
    }

    /**
     * 上传图片
     */
    @RequestMapping("/upload")
    public ResultEntity upload(@RequestParam MultipartFile file) {
        service.upload(file);
        return ResultEntity.success();
    }

    /**
     * 查看标记后的图片
     */
    @RequestMapping("/download")
    public ResultEntity download(String id, int index, HttpServletResponse response) {
        service.download(id, index, response);
        return ResultEntity.success();
    }

    /**
     * 再次获取识别后信息
     */
    @RequestMapping("/getTextMessage")
    public ResultEntity getTextMessage(String id, int index) {
        return service.getTextMessage(id, index);
    }

    @Override
    protected SqlQuery<OcrRecord> buildPageQuery(HttpServletRequest httpServletRequest, OcrRecord ocrRecord) {
        return SqlQuery.from(OcrRecord.class).orderByDesc(OcrRecordInfo.CREATEDATE);
    }

}
