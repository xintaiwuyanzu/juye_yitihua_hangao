package com.dr.archive.fuzhou.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.dr.archive.fuzhou.entity.OcrRecord;
import com.dr.archive.fuzhou.ocrEntity.GeneralBo;
import com.dr.archive.fuzhou.ocrEntity.GeneralResult;
import com.dr.archive.fuzhou.service.OcrGeneralClient;
import com.dr.archive.fuzhou.service.OcrService;
import com.dr.archive.fuzhou.util.TifToImg;
import com.dr.framework.common.entity.ResultEntity;
import com.dr.framework.common.file.autoconfig.CommonFileConfig;
import com.dr.framework.common.service.DefaultBaseService;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class OcrServiceImpl extends DefaultBaseService<OcrRecord> implements OcrService {
    @Autowired
    CommonFileConfig commonFileConfig;
    @Autowired
    OcrGeneralClient generalClient;
    @Autowired
    TifToImg tifToImg;

    /**
     * 在线图片转换成base64字符串(相对路径模板使用)
     *
     * @return
     */
    @Override
    public String imageToBase64(OcrRecord ocrRecord) {
        File file = getFullPathByUid(commonFileConfig.getWebPath(), ocrRecord.getFileUid() + "." + ocrRecord.getFileType());
        String img = null;
        try {
            img = Base64Utils.encodeToString(FileUtils.readFileToByteArray(file));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return img;
    }

    @Override
    public void upload(MultipartFile file) {
        String uid = System.currentTimeMillis() + "";
        String fullName = file.getOriginalFilename();
        String fromType = fullName.substring(fullName.lastIndexOf(".") + 1);//源文件类型
        try {
            //保存源文件
            String fromPath = commonFileConfig.getFullDirPath("OCR", "from", new Date()) + File.separator + uid + "." + fromType;
            saveFile(fromPath, file.getBytes());
            OcrRecord ocrRecord = new OcrRecord(uid, fullName, fromType, file.getSize(), uid + "." + fromType + ",");
            if (fromType.startsWith("tif")) {
                String s = tifToImg.tiffToJpg(fromPath, uid);
                ocrRecord.setFileType("jpg");
                ocrRecord.setToFiles(s);
            }
            //保存到数据库
            this.insert(ocrRecord);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveFile(String savePath, byte[] bytes) throws Exception {
        new FileOutputStream(savePath).write(bytes);
        BufferedImage image = ImageIO.read(new FileInputStream(savePath));
        int width = 800;
        int height = 1000;
        if (image.getWidth() < 800) {
            width = image.getWidth();
        }
        if (image.getHeight() < 1000) {
            height = image.getHeight();
        }
        Image resultingImage = image.getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING);
        BufferedImage outputImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        outputImage.getGraphics().drawImage(resultingImage, 0, 0, null);
        ImageIO.write(outputImage, "jpg", new File(savePath));
    }

    /**
     * 通过文件名获取绝对路径的文件
     *
     * @param root     files文件夹的绝对路径
     * @param fileName 文件名
     * @return
     */
    public File getFullPathByUid(String root, String fileName) {
        File baseDir = new File(root);// 创建一个File对象
        // 判断目录是否存在
        if (!baseDir.exists() || !baseDir.isDirectory()) {
            return null;
        }
        //判断目录是否存在
        File[] files = baseDir.listFiles();
        if (files != null) {
            for (File tempFile : files) {
                if (tempFile.isDirectory()) {
                    File file = getFullPathByUid(tempFile.getAbsolutePath(), fileName);
                    if (file != null) {
                        return file;
                    }
                } else if (tempFile.isFile()) {
                    String tempName = tempFile.getName();
                    if (tempName.equals(fileName)) {
                        return tempFile.getAbsoluteFile();
                    }
                }
            }
        }
        return null;
    }

    /**
     * 从服务器加载图片
     */
    @Override
    public void download(String id, int index, HttpServletResponse response) {
        if (!"undefined".equals(id) && StringUtils.hasText(id)) {
            OcrRecord record = selectById(id);
            String[] files = record.getToFiles().split(",");
            File file = getFullPathByUid(commonFileConfig.getWebPath(), files[index]);
            FileInputStream fis;
            try {
                fis = new FileInputStream(file);
                byte[] bytes = new byte[fis.available()];
                fis.read(bytes);
                response.reset();
                response.setHeader("Content-Type", "application/json");
                response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(record.getFileName() + "." + record.getFileType(), "UTF-8"));
                OutputStream out = response.getOutputStream();
                out.write(bytes);
                fis.close();
                out.flush();
                out.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
    }

    /**
     * 点击查看时再次获取识别后的信息
     */
    @Override
    public ResultEntity getTextMessage(String id, int index) {
        try {
            OcrRecord record = selectById(id);
            //获取图片
            String[] files = record.getToFiles().split(",");
            File jsonFile = getFullPathByUid(commonFileConfig.getFullDirPath("OCR", "to", null), record.getFileUid() + ".json");
            if (jsonFile == null) {
                File file = getFullPathByUid(commonFileConfig.getWebPath(), files[index]);
                //识别图片用于返回文字和位置信息
                List<String> list = new ArrayList<>();
                list.add(Base64Utils.encodeToString(FileUtils.readFileToByteArray(file)));//字节转Base64
                GeneralBo generalBo = new GeneralBo(true, true, list);
                GeneralResult result = generalClient.general(generalBo);
                boolean b = createJsonFile(result.getData(), record.getFileUid());
                if (b) {
                    return ResultEntity.success(result.getData());
                } else {
                    return ResultEntity.error(result.getMessage());
                }
            } else {
                FileReader fileReader = new FileReader(jsonFile);
                Reader reader = new InputStreamReader(new FileInputStream(jsonFile), "utf-8");
                int ch;
                StringBuffer sb = new StringBuffer();
                while ((ch = reader.read()) != -1) {
                    sb.append((char) ch);
                }
                fileReader.close();
                reader.close();
                return ResultEntity.success(sb.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 将JSON数据格式化并保存到文件中
     *
     * @param jsonData 需要输出的json数据
     * @return
     */
    public boolean createJsonFile(Object jsonData, String uid) {
        //输出的文件地址
        String filePath = commonFileConfig.getFullDirPath("OCR", "to", new Date()) + File.separator + uid + ".json";

        String content = JSON.toJSONString(jsonData, SerializerFeature.PrettyFormat, SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteDateUseDateFormat);
        // 标记文件生成是否成功
        boolean flag = true;
        // 生成json格式文件
        try {
            // 保证创建一个新文件
            File file = new File(filePath);
            if (file.exists()) { // 如果已存在,删除旧文件
                file.delete();
            }
            boolean t = file.createNewFile();
            // 将格式化后的字符串写入文件
            Writer write = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
            write.write(content);
            write.flush();
            write.close();
        } catch (Exception e) {
            flag = false;
            e.printStackTrace();
        }
        return flag;
    }
}
