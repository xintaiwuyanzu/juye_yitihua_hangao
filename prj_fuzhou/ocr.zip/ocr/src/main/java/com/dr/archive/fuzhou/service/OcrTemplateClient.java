package com.dr.archive.fuzhou.service;

import com.dr.archive.fuzhou.ocrEntity.TemplateBo;
import com.dr.archive.fuzhou.ocrEntity.TemplateResult;
import com.dr.archive.fuzhou.service.impl.FeignClientTemplateConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * ofd接口客户端
 * @author yang
 * @date 2022-05-19 10:38
 */
@FeignClient(name = "ocr-template-client", url = "${ocr.base-url}", configuration = FeignClientTemplateConfig.class)
public interface OcrTemplateClient {
    /**
     * 自定义模板识别
     *
     * @param templateBo
     * @return
     */
    @PostMapping(value = "v1/document/ocr/template")
    TemplateResult template(@RequestBody TemplateBo templateBo);
}
